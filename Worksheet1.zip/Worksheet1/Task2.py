# Enhetsomvandling
a=640
inch=a*100/2.54
foot=inch/12
yard=foot/3
mile=yard/1760
print(a,'meter')
print(inch,'inches')
print(foot,'feet')
print(yard,'yards')
print(mile,'miles')