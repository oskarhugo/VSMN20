P=1000 #principle amount
r=5 #interest rate
n=3 #number of years
A=P*(1+r/100)**n
print('Amount after', n, 'years = ',A,'kr')